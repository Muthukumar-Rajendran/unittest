﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using System.Threading.Tasks;
using WebApplication.Interface;
using WebApplication.Controllers;
using WebApplication.service;
using WebApplication.model;
using Microsoft.Extensions.Logging;
using Moq;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Mvc;

namespace webapptest
{
    public class Logintest
    {
        private readonly Mock<ILogger<LoginController>> _mocklogger;
        private readonly Mock<ILoginService> _mockinterface;
        private readonly Mock<Loginservice> _mockservice;
      //  private readonly Mock<ApplicationSettings> _mockappSettings;
        private readonly Mock<IOptions<ApplicationSettings>> _mockappsettings;


        public Logintest()
        {
            _mocklogger = new Mock<ILogger<LoginController>>();
            _mockinterface = new Mock<ILoginService>();
            _mockservice = new Mock<Loginservice>();
           // _mockappSettings = new  Mock<ApplicationSettings > ();
            _mockappsettings = new Mock<IOptions<ApplicationSettings>>();

        }

        //GET TEST CASE

        [Fact]
        public void logindetailsget()
        {
            LoginModel loginmodel = new LoginModel();
            Logindetails employee = new Logindetails();

            loginmodel.username = "Maheswaran";
            loginmodel.pwd = "mahes@123";

            var data = new Logindetails
            {
                id = 1,
                username = "Maheswaran",
                pwd = "mahes@123",
                email = "Maheswaran.Sappanimuthu@bshg.com",
                skills = "Webdevelopment",
                photo = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTOkHm3_mPQ5PPRvGtU6Si7FJg8DVDtZ47rw&usqp=CAU",
                logintype = "superadmin"


            };
            Logindetails login = new Logindetails();
            employee.id = 1;
            employee.username =" Maheswaran";
            employee.pwd = "mahes@123";



            LoginController loginController = new LoginController(_mockinterface.Object, _mocklogger.Object,_mockappsettings.Object);
            var post = loginController.Get(loginmodel);
            Assert.Equal(post, post);

        }

        [Fact]
        public void LoginNotNull()
        {
            LoginModel loginmodel = new LoginModel();
            Logindetails employee = new Logindetails();

            loginmodel.username = "Maheswaran";
            loginmodel.pwd = "mahes@123";

            var data = new Logindetails
            {
                id = 1,
                username = "Maheswaran",
                pwd = "mahes@123",
                email = "Maheswaran.Sappanimuthu@bshg.com",
                skills = "Webdevelopment",
                photo = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTOkHm3_mPQ5PPRvGtU6Si7FJg8DVDtZ47rw&usqp=CAU",
                logintype = "superadmin"


            };
            Logindetails login = new Logindetails();
            employee.id = 1;
            employee.username = " Maheswaran";
            employee.pwd = "mahes@123";



            LoginController loginController = new LoginController(_mockinterface.Object, _mocklogger.Object, _mockappsettings.Object);
            var post = loginController.Get(loginmodel);
            if (post != null)
                Assert.NotNull(post);

        }

        [Fact]
        public void LoginNotBadRequest()
        {
            LoginModel loginmodel = new LoginModel();
            Logindetails employee = new Logindetails();

            loginmodel.username = "Maheswaran";
            loginmodel.pwd = "mahes@123";

            var data = new Logindetails
            {
                id = 1,
                username = "Maheswaran",
                pwd = "mahes@123",
                email = "Maheswaran.Sappanimuthu@bshg.com",
                skills = "Webdevelopment",
                photo = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTOkHm3_mPQ5PPRvGtU6Si7FJg8DVDtZ47rw&usqp=CAU",
                logintype = "superadmin"


            };
            Logindetails login = new Logindetails();
            employee.id = 1;
            employee.username = " Maheswaran";
            employee.pwd = "mahes@123";



            LoginController loginController = new LoginController(_mockinterface.Object, _mocklogger.Object, _mockappsettings.Object);
            var post = loginController.Get(loginmodel);
            Assert.IsNotType<BadRequestResult>(post);
        }

    }
}
