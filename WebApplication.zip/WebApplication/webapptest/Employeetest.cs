﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using System.Threading.Tasks;
using WebApplication.Interface;
using WebApplication.Controllers;
using WebApplication.service;
using WebApplication.model;
using Microsoft.Extensions.Logging;
using Moq;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Mvc;

namespace webapptest
{
    public class Employeetest
    {
        
        private readonly Mock<ILogger<EmpdetailController>> _mocklogger;
        private readonly Mock<Empdetailservice> _mockservice;
       
        
        public Employeetest()
        {
            
            _mocklogger = new Mock<ILogger<EmpdetailController>>();
           _mockservice = new Mock<Empdetailservice>();
           

            
            }
        [Fact]
        public void EmployeeDetailGet()
        {
            LoginModel login = new LoginModel();
            Paging paging = new Paging();
            Empdetails empdetails = new Empdetails();
            login.username = "Maheswaran";
            login.pwd = "mahes@123";

            var data = new Empdetails
            {
                id = 1,
                name = "Maheswaran",
                employeeid = 001,
                email = "Maheswaran.Sappanimuthu@bshg.com",
                skills = "Webdevelopment",
                photo = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTOkHm3_mPQ5PPRvGtU6Si7FJg8DVDtZ47rw&usqp=CAU"
        };

        Empdetails emp = new Empdetails();
        empdetails.id = 1;
            empdetails.name = "Maheswaran";
            empdetails.employeeid = 001;

            EmpdetailController empdetailController = new EmpdetailController(_mockservice.Object,_mocklogger.Object);
            var post = empdetailController.Get(paging);
            Assert.Equal(post, post);
        }

        [Fact]
        public void EmployeeNotNull()
        {
            LoginModel login = new LoginModel();
            Paging paging = new Paging();
            Empdetails empdetails = new Empdetails();
            login.username = "Maheswaran";
            login.pwd = "mahes@123";

            var data = new Empdetails
            {
                id = 1,
                name = "Maheswaran",
                employeeid = 001,
                email = "Maheswaran.Sappanimuthu@bshg.com",
                skills = "Webdevelopment",
                photo = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTOkHm3_mPQ5PPRvGtU6Si7FJg8DVDtZ47rw&usqp=CAU"
            };

            Empdetails emp = new Empdetails();
            empdetails.id = 1;
            empdetails.name = "Maheswaran";
            empdetails.employeeid = 001;

            EmpdetailController empdetailController = new EmpdetailController(_mockservice.Object, _mocklogger.Object);
            var post = empdetailController.Get(paging);
            if (post != null)
                Assert.NotNull(post);
        }


        [Fact]
        public void EmployeeNotBadRequest()
        {
            LoginModel login = new LoginModel();
            Paging paging = new Paging();
            Empdetails empdetails = new Empdetails();
            login.username = "Maheswaran";
            login.pwd = "mahes@123";

            var data = new Empdetails
            {
                id = 1,
                name = "Maheswaran",
                employeeid = 001,
                email = "Maheswaran.Sappanimuthu@bshg.com",
                skills = "Webdevelopment",
                photo = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTOkHm3_mPQ5PPRvGtU6Si7FJg8DVDtZ47rw&usqp=CAU"
            };

            Empdetails emp = new Empdetails();
            empdetails.id = 1;
            empdetails.name = "Maheswaran";
            empdetails.employeeid = 001;

            EmpdetailController empdetailController = new EmpdetailController(_mockservice.Object, _mocklogger.Object);
            var post = empdetailController.Get(paging);
            Assert.IsType<Empdetails>(data);
        }

        //POST TEST CASE

        [Fact]
        public void EmployeePostNotNull()
        {
            LoginModel login = new LoginModel();
            Paging paging = new Paging();
            Empdetails empdetails = new Empdetails();
            login.username = "Maheswaran";
            login.pwd = "mahes@123";

            var data = new Empdetails
            {
                id = 1,
                name = "Maheswaran",
                employeeid = 001,
                email = "Maheswaran.Sappanimuthu@bshg.com",
                skills = "Webdevelopment",
                photo = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTOkHm3_mPQ5PPRvGtU6Si7FJg8DVDtZ47rw&usqp=CAU"
            };

            Empdetails emp = new Empdetails();
            empdetails.id = 1;
            empdetails.name = "Maheswaran";
            empdetails.employeeid = 001;

            EmpdetailController empdetailController = new EmpdetailController(_mockservice.Object, _mocklogger.Object);
            var post = empdetailController.Post(data);
            if (post != null)
                Assert.NotNull(data);
        }

        [Fact]
        public void EmployeePostNotBadRequest()
        {
            LoginModel login = new LoginModel();
            Paging paging = new Paging();
            Empdetails empdetails = new Empdetails();
            login.username = "Maheswaran";
            login.pwd = "mahes@123";

            var data = new Empdetails
            {
                id = 1,
                name = "Maheswaran",
                employeeid = 001,
                email = "Maheswaran.Sappanimuthu@bshg.com",
                skills = "Webdevelopment",
                photo = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTOkHm3_mPQ5PPRvGtU6Si7FJg8DVDtZ47rw&usqp=CAU"
            };

            Empdetails emp = new Empdetails();
            empdetails.id = 1;
            empdetails.name = "Maheswaran";
            empdetails.employeeid = 001;

            EmpdetailController empdetailController = new EmpdetailController(_mockservice.Object, _mocklogger.Object);
            var post = empdetailController.Post(data);
            Assert.IsType<Empdetails>(data);
        }

        // UPDATE TEST CASE


        [Fact]
        public void EmployeeUpdateNotNull()
        {
            LoginModel login = new LoginModel();
            Paging paging = new Paging();
            Empdetails empdetails = new Empdetails();
            login.username = "Maheswaran";
            login.pwd = "mahes@123";

            var data = new Empdetails
            {
                id = 1,
                name = "Maheswaran",
                employeeid = 001,
                email = "Maheswaran.Sappanimuthu@bshg.com",
                skills = "Webdevelopment",
                photo = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTOkHm3_mPQ5PPRvGtU6Si7FJg8DVDtZ47rw&usqp=CAU"
            };
            int id = data.id;
            Empdetails emp = new Empdetails();
            empdetails.id = 1;
            empdetails.name = "Maheswaran";
            empdetails.employeeid = 001;

            EmpdetailController empdetailController = new EmpdetailController(_mockservice.Object, _mocklogger.Object);
            var post = empdetailController.Put(id, data);
            if (post != null)
                Assert.NotNull(data);
        }

        [Fact]
        public void EmployeeUpdateNotBadRequest()
        {
            LoginModel login = new LoginModel();
            Paging paging = new Paging();
            Empdetails empdetails = new Empdetails();
            login.username = "Maheswaran";
            login.pwd = "mahes@123";

            var data = new Empdetails
            {
                id = 1,
                name = "Maheswaran",
                employeeid = 001,
                email = "Maheswaran.Sappanimuthu@bshg.com",
                skills = "Webdevelopment",
                photo = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTOkHm3_mPQ5PPRvGtU6Si7FJg8DVDtZ47rw&usqp=CAU"
            };
            int id = data.id;
            Empdetails emp = new Empdetails();
            empdetails.id = 1;
            empdetails.name = "Maheswaran";
            empdetails.employeeid = 001;

            EmpdetailController empdetailController = new EmpdetailController(_mockservice.Object, _mocklogger.Object);
            var post = empdetailController.Put(id, data);
            Assert.IsNotType<BadRequestResult>(post);
        }

        //DELETE TEST CASE

        [Fact]
        public void EmployeeDelete()
        {
            LoginModel login = new LoginModel();
            Paging paging = new Paging();
            Empdetails empdetails = new Empdetails();
            login.username = "Maheswaran";
            login.pwd = "mahes@123";

            var data = new Empdetails
            {
                id = 1,
                name = "Maheswaran",
                employeeid = 001,
                email = "Maheswaran.Sappanimuthu@bshg.com",
                skills = "Webdevelopment",
                photo = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTOkHm3_mPQ5PPRvGtU6Si7FJg8DVDtZ47rw&usqp=CAU"
            };

            Empdetails emp = new Empdetails();
            empdetails.id = 1;
            empdetails.name = "Maheswaran";
            empdetails.employeeid = 001;

            EmpdetailController empdetailController = new EmpdetailController(_mockservice.Object, _mocklogger.Object);
            var post = empdetailController.Delete(empdetails.id);
            Assert.Equal(post, post);
        }
           

            

    }
}
