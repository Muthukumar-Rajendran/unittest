using System;
using Xunit;

namespace webapptest
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
