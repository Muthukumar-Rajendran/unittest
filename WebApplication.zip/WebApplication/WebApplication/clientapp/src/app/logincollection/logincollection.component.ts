import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-logincollection',
  templateUrl: './logincollection.component.html',
  styleUrls: ['./logincollection.component.css']
})
export class LogincollectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
