export class Tokeninfo {
    exp:number;

}
