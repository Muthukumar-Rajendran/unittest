import { Employeecollection } from './employeecollection';

describe('Employeecollection', () => {
  it('should create an instance', () => {
    expect(new Employeecollection()).toBeTruthy();
  });
});
