export class Employeedetail {
    id?:any;
    employeeid:any;
    name:string;
    skills:string;
    email:string;
    photo:string;
   
}
