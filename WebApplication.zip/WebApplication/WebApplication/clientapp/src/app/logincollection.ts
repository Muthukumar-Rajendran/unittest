import { Empdetails } from './empdetails';

export class Logincollection {
     logindetails: Empdetails[];
        token:string; 
     
      

}
