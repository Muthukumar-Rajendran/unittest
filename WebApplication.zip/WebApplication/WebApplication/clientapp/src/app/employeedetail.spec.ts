import { Employeedetail } from './employeedetail';

describe('Employeedetail', () => {
  it('should create an instance', () => {
    expect(new Employeedetail()).toBeTruthy();
  });
});
