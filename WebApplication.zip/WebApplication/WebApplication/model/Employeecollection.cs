﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication.model
{
    public class Employeecollection
    {
        public List<Empdetails> employee { get; set; }
        public int employeecount { get; set; }
    }
}
