﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication.model
{
    public class Logindetails
    {
        public string username { get; set; }
        public string pwd { get; set; }
        public int id { get; set; }
        public string email { get; set; }
        public string skills { get; set; }
        public string photo { get; set; }
        public string logintype { get; set; }



    }
}
