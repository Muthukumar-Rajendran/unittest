﻿using Couchbase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication.Interface;
using WebApplication.model;

namespace WebApplication.service
{
    public class Empdetailservice : IempdetailService
    {
        public async Task<Empdetails> DeleteEmployees(ICluster cluster, int id)
        {
            var queryResult = await cluster.QueryAsync<Empdetails>("SELECT id,employeeid,name,email,skills,photo FROM Employeedetails where id= " + id.ToString(), new Couchbase.Query.QueryOptions());
            var bucket = await cluster.BucketAsync("Employeedetails");
            var collection = bucket.DefaultCollection();

            await collection.RemoveAsync(id.ToString());
            return null;
        }

        public async Task<Empdetails> GetEmployeeBYid(ICluster cluster, int id)
        {
            Empdetails employee = new Empdetails();
            var queryResult = await cluster.QueryAsync<Empdetails>("SELECT id,employeeid,name,email,skills,photo FROM Employeedetails where id=" + id, new Couchbase.Query.QueryOptions());



            await foreach (var row in queryResult)
            {
                employee = row;
            }

            return employee;
        }

        public async Task<List<Empdetails>> GetEmployees(ICluster cluster,Paging paging)
        {
           

                var queryResult = await cluster.QueryAsync<Empdetails>($"SELECT id,employeeid,name,email,skills,photo FROM Employeedetails OFFSET {paging.start} LIMIT {paging.end} ", new Couchbase.Query.QueryOptions());

                List<Empdetails> empList = new List<Empdetails>();

                await foreach (var row in queryResult)
                {
                    empList.Add(row);
                }

                return empList;
          
        }

        public async Task<ICluster> Initialize()
        {
            var cluster = await Cluster.ConnectAsync("couchbase://localhost", "Administrator", "123456");
            return cluster;
        }

        public async Task<Empdetails> PutEmployeeBYid(ICluster cluster, int id, Empdetails value)
        {
            var bucket = await cluster.BucketAsync("Employeedetails");
            var collection = bucket.DefaultCollection();
            await collection.UpsertAsync(id.ToString(), value);

            return null;

        }
        //create
        public async Task<Empdetails> PostEmploye(ICluster cluster, Empdetails value)
        {

            var bucket = await cluster.BucketAsync("Employeedetails");
            var collection = bucket.DefaultCollection();
            int idvalue = value.id;
            await collection.InsertAsync(idvalue.ToString(), value);


            return null;
        }
        public async Task<List<Empdetails>>Getemployeescount(ICluster cluster)
        {
            List<Empdetails> empdetails = new List<Empdetails>();
            var queryresult = await cluster.QueryAsync<Empdetails>($"SELECT id,employeeid,name,email,skills,photo FROM Employeedetails", new Couchbase.Query.QueryOptions());

            await foreach (var row in queryresult)
            {
                empdetails.Add(row);
            }
            return empdetails;
        }


    }
}
