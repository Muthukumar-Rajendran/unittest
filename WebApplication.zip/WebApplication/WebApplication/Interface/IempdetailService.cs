﻿using Couchbase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication.model;

namespace WebApplication.Interface
{
    public interface IempdetailService
    {
        Task<ICluster> Initialize();
        Task<List<Empdetails>> GetEmployees(ICluster cluster,Paging paging);
        Task<Empdetails> GetEmployeeBYid(ICluster cluster,int id);
        Task<Empdetails> DeleteEmployees(ICluster cluster,int id);
        Task<Empdetails> PutEmployeeBYid(ICluster cluster,int id, Empdetails value);
        Task<Empdetails> PostEmploye(ICluster cluster, Empdetails value);
        Task<List<Empdetails>> Getemployeescount(ICluster cluster);
    }
}
