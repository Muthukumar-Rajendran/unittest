﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WebApplication.Interface;
using WebApplication.model;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]


    public class EmpdetailController : ControllerBase
    {
        private readonly ILogger<EmpdetailController> logger;
        private readonly IempdetailService _service;
        public EmpdetailController(IempdetailService service, ILogger<EmpdetailController> logger)
        {
            this.logger = logger;
            _service = service;
        }

        // GET: api/<EmpdetailController>
        [HttpGet]
        [Authorize(Roles = "superadmin,admin,user")]


        public async Task<Employeecollection> Get([FromQuery] Paging paging )
        {
            Employeecollection emp = new Employeecollection();
            logger.LogInformation("getting employees");
            var couchClient = await _service.Initialize();
            var employees = await _service.GetEmployees(couchClient , paging);
            var employee = await _service.Getemployeescount(couchClient);
            if (employees == null)
            {
                logger.LogWarning("can't get employees");
            }
            int count = employee.Count;
            emp.employee = employees;
            emp.employeecount = count;

            return emp;
        }

        // GET api/<EmpdetailController>/5
        [HttpGet("{id}")]
        [Authorize(Roles = "superadmin,admin,user")]


        public async Task<Empdetails> Get(int id)
        {
            var couchClient = await _service.Initialize();
            var employees = await _service.GetEmployeeBYid(couchClient, id);
            logger.LogInformation("Login details");
            return employees;

        }
        //UPDATE
        // PUT api/<EmpdetailController>/5
        [HttpPut("{id}")]
        [Authorize(Roles = "superadmin,admin")]


        public async Task<Empdetails> Put(int id, [FromBody] Empdetails value)
        {
            var couchClient = await _service.Initialize();
            await _service.PutEmployeeBYid(couchClient, id, value);
            logger.LogInformation("Update successfull");
            return null;

        }


        // DELETE api/<EmpdetailController>/5
        [HttpDelete("{id}")]
        [Authorize(Roles = "superadmin")]


        public async Task<Empdetails> Delete(int id)
        {
            var couchClient = await _service.Initialize();
            await _service.DeleteEmployees(couchClient, id);
            logger.LogInformation("successfully deleted");
            return null;


        }
        // POST api/<EmployeeController>
        [HttpPost]
        [Authorize(Roles = "superadmin,admin")]


        public async Task Post([FromBody] Empdetails value)
        {
            var couchClient = await _service.Initialize();
            await _service.PostEmploye(couchClient, value);
            logger.LogInformation("successfully added");


        }


    }
}
